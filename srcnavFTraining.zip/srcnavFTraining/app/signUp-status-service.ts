import { Injectable} from '@angular/core';


@Injectable({
  providedIn: 'root'
})
export class SignUpStatusService {



  constructor() { }
  userSignUpStatus:boolean;
  mentorSignUpStatus:boolean;

  setUserSignUpStatus(signUpStatus:boolean){
    this. userSignUpStatus = signUpStatus;
      }
    
      getUserSignUpStatus() :boolean {
        return this. userSignUpStatus;
      }
    
      setMentorSignUpStatus(signUpStatus:boolean){
        this.mentorSignUpStatus = signUpStatus;
          }
        
          getMentorSignUpStatus() :boolean {
            return this.mentorSignUpStatus;
          }




}