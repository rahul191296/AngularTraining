import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WelcomeComponent } from './home/welcome.component';
import { UserLoginComponent } from './user/user-login.component';
import { RouterModule } from '@angular/router';
import { MentorLoginComponent } from './mentor/mentor-login.component';
import { AdminLoginComponent } from './admin/admin-login.component';

import { UserRegisterComponent } from './user/user-register.component';
import { MentorRegisterComponent } from './mentor/mentor-register.component';
import { UserMenuComponent } from './user/user-menu.component';
import { MentorMenuComponent } from './mentor/mentor-menu.component';
import {FooterComponent } from './footer/footer.component';
import { AdminMenuComponent } from './admin/admin-menu.component';
import { HttpClientModule } from '@angular/common/http';
import { UcompletedTrainingComponent } from './trainings/user-training/ucompleted-training.component';
import { UcurrentTrainingComponent } from './trainings/user-training/ucurrent-training.component';
import { McompletedTrainingComponent } from './trainings/mentor-training/mcompleted-training.component';
import { McurrentTrainingComponent } from './trainings/mentor-training/mcurrent-training.component';







@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    WelcomeComponent,
    UserLoginComponent,
    MentorLoginComponent,
    AdminLoginComponent,
    UserRegisterComponent,
    MentorRegisterComponent,

    UcompletedTrainingComponent,
    UcurrentTrainingComponent,
    McompletedTrainingComponent,
    McurrentTrainingComponent,

    UserMenuComponent,
    MentorMenuComponent,
    AdminMenuComponent
],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    
 RouterModule.forRoot([
 
  { path: 'admin-login', component: AdminLoginComponent },
  { path: 'mentor-login', component: MentorLoginComponent },
 { path: 'user-login', component: UserLoginComponent },

  { path: 'mentor-register', component: MentorRegisterComponent },
 { path: 'user-register', component: UserRegisterComponent },

 { path: 'user-menu', component: UserMenuComponent , children : [
   { path: 'user-completed-tr' , component: UcompletedTrainingComponent},
   { path: 'user-current-tr' , component: UcurrentTrainingComponent}
                ]
              },
 { path: 'mentor-menu', component: MentorMenuComponent , children : [
   { path: 'mentor-completed-tr' , component: McompletedTrainingComponent},
   { path: 'mentor-current-tr' , component: McurrentTrainingComponent}
               ]
             },
 { path: 'admin-menu', component: AdminMenuComponent }, 


{ path: 'mentor-completed-tr' , component: McompletedTrainingComponent},
{ path: 'mentor-current-tr' , component: McurrentTrainingComponent},

 { path: '**', redirectTo: 'welcome', pathMatch: 'full' },
 { path: '', redirectTo: 'welcome', pathMatch: 'full' }
  
]),
   
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
