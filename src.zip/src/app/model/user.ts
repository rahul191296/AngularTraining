export class User {
   
    name: string;
    email: string;
    password: string;
    contactNo: string;
    dob: string;
}