import { Injectable} from '@angular/core';
import { HttpClient, HttpHeaders  } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../model/user';



const httpOptions = {
    headers : new HttpHeaders({ 'content-type' : 'application/json'})
       }

       
@Injectable({
    providedIn: 'root'
  })
export class UserService {

  
       
        constructor(private http : HttpClient){
      
        }
        
        userRegister(user : User) {
           
            return this.http.post('/server/user/register', user)
        }

     /* getProducts() : Observable<IProduct[]> {
          return this.http.get<IProduct[]>(this.productUrl).pipe(
            tap(data => console.log('all: '+ JSON.stringify(data))), 
            catchError(this.handleError)
          
          );
      }
      
      private handleError(err : HttpErrorResponse) {
       let errorMessage  = 'error';
       return throwError(errorMessage);
      }    */
      }



