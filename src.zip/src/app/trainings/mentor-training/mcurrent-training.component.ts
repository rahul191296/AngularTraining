import { Component, OnInit } from '@angular/core';


@Component({
    selector: 'mentor-current-training',
    templateUrl: './mcurrent-training.component.html'
})
export class McurrentTrainingComponent implements OnInit{
    ngOnInit(): void {
      
    }
  
}